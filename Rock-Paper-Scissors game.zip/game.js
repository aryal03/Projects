let playerScore = 0;
let computerScore = 0;

function game(playerChoice) {
    const choices = ['rock', 'paper', 'scissors'];
    const computerChoice = choices[Math.floor(Math.random() * 3)];
    let result = '';

    if (playerChoice === computerChoice) {
        result = 'It\'s a draw!';
    } else if (
        (playerChoice === 'rock' && computerChoice === 'scissors') ||
        (playerChoice === 'scissors' && computerChoice === 'paper') ||
        (playerChoice === 'paper' && computerChoice === 'rock')
    ) {
        result = 'You win!';
        playerScore++;
    } else {
        result = 'You lose!';
        computerScore++;
    }

    document.getElementById('result').innerText = `You chose ${playerChoice} and the Computer chose ${computerChoice}. ${result}`;
    document.getElementById('score').innerText = `Player: ${playerScore} and Computer: ${computerScore}`;
}
